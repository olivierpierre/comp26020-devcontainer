#ifndef PARSER_H
#define PARSER_H

#include "network.h" /* needed for the definition of request */

void parse_req(request *r);

#endif
